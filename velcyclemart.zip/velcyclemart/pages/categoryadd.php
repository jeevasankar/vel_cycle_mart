<?php 
    include 'config.php';
    if(isset($_POST['submit'])){
        
    
        $Name = $_POST['Name'];

        $requete = $con->prepare("INSERT INTO category_table (CATEGORY) VALUES('$Name')");
        //$requete->execute(array($image,$Name,$Email,$Phone,$EnrollNumber,$DateOfAdmission));
        $requete->execute();
    }
    header('location:category_list.php')
    ?>