<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php
session_start();
include 'config.php';

// Check if Id is set in GET parameters
if(isset($_GET['Id'])) {
    $_SESSION["id"] = $_GET['Id'];
    $id = $_SESSION["id"];

    // Prepare and execute the SQL query
    $statement = $con->prepare("SELECT * FROM main_table WHERE Id = ?");
    $statement->bind_param("i", $id);
    $statement->execute();

    // Check if the query was successful
    if($result = $statement->get_result()) {
        // Check if any rows were returned
        if($result->num_rows > 0) {
            // Fetch the row as an associative array
            $table = $result->fetch_assoc();
        } else {
            // No rows found, handle this case (e.g., show an error message)
            echo "No data found for the specified Id.";
            exit; // Stop execution
        }
    } else {
        // Query execution failed, handle this case (e.g., show an error message)
        echo "Error executing query: " . $con->error;
        exit; // Stop execution
    }
} else {
    // Id is not set in GET parameters, handle this case (e.g., redirect to a different page)
    echo "Id parameter is missing.";
    exit; // Stop execution
}
?>

<div class="container w-50">


<form method="POST" action="mainupdate.php" enctype="multipart/form-data">
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">img:</label>
                                    <input type="file" class="form-control" id="recipient-name" accept=".jpg,.png,.jpeg" name="IMAGES">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">CYCLE_NAME</label>
                                    <input type="text" class="form-control" id="recipient-name" name="CYCLE_NAME" value="<?php echo $table['CYCLE_NAME']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">BRAND</label>
                                    <input type="text" class="form-control" id="recipient-name" name="BRAND" value="<?php echo $table['BRAND']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">CATEGORY</label>
                                    <input type="text" class="form-control" id="recipient-name" name="CATEGORY" value="<?php echo $table['CATEGORY']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">OLD_PRICE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="OLD_PRICE" value="<?php echo $table['OLD_PRICE']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">NEW_PRICE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="NEW_PRICE" value="<?php echo $table['NEW_PRICE']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">ABOUT_CYCLE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="ABOUT_CYCLE" value="<?php echo $table['ABOUT_CYCLE']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">FRAME</label>
                                    <input type="text" class="form-control" id="recipient-name" name="FRAME" value="<?php echo $table['FRAME']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">FORK</label>
                                    <input type="text" class="form-control" id="recipient-name" name="FORK" value="<?php echo $table['FORK']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">GEAR</label>
                                    <input type="text" class="form-control" id="recipient-name" name="GEAR" value="<?php echo $table['GEAR']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">TYRE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="TYRE" value="<?php echo $table['TYRE']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">BRAKES</label>
                                    <input type="text" class="form-control" id="recipient-name" name="BRAKES" value="<?php echo $table['BRAKES']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">RIMS</label>
                                    <input type="text" class="form-control" id="recipient-name" name="RIMS" value="<?php echo $table['RIMS']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">BOTTOM_BRACKET</label>
                                    <input type="text" class="form-control" id="recipient-name" name="BOTTOM_BRACKET" value="<?php echo $table['BOTTOM_BRACKET']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">RIDING_PURPOSE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="RIDING_PURPOSE" value="<?php echo $table['RIDING_PURPOSE']?>">
                                  </div>
                                  
                                  <div class="modal-footer">
                                <button type="submit" name="submit" class="btn btn-primary">Update student</button>
                              </div>
                                </form>
</div>
    <script src="../js/script.js"></script>
    <script src="../js/bootstrap.bundle.js"></script>
</body>
</html>