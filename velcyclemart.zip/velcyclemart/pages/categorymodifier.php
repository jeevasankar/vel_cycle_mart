<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php
    session_start();
    include 'config.php';
    $_SESSION["id"] = $_GET['Id'];
    $id = $_SESSION["id"];
    $statement = $con->prepare("SELECT * FROM category_table WHERE Id = ?");
    $statement->bind_param("i", $id);
    $statement->execute();
    $result = $statement->get_result();
    
    if($result !== false && $result->num_rows > 0) {
        $table = $result->fetch_assoc();
?>
<div class="container w-50">
    <form method="POST" action="categoryupdate.php" enctype="multipart/form-data">
        <div class="">
            <label for="recipient-name" class="col-form-label">Name:</label>
            <input type="text" class="form-control" id="recipient-name" name="Name" value="<?php echo $table['CATEGORY']?>">
        </div>
        <div class="modal-footer">
            <button type="submit" name="submit" class="btn btn-primary">Update student</button>
        </div>
    </form>
</div>
<?php
    } elseif ($result === false) {
        echo "Error executing query: " . $con->error;
    } else {
        echo "No category found with ID: " . $id;
    }
?>

    <script src="../js/script.js"></script>
    <script src="../js/bootstrap.bundle.js"></script>
</body>
</html>