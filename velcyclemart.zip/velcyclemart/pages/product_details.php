<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Product Detail Page</title>
<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #e671b7;
  }

  .container {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    margin: 20px;
  }

  .cycle-image {
    flex: 1;
    margin-right: 20px;
  }

  .cycle-image img {
    max-width: 100%;
    border-radius: 10px;
  }

  .cycle-details {
    flex: 1;
  }

  .cycle-details h2 {
    color: #333;
  }

  .icon {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
  }

  .icon img {
    margin-right: 10px;
  }
  p{
    margin: 1rem 0;
    font-size: 1rem;
    font-weight: 700;
  }
  @media (max-width: 768px) {
    .container {
      flex-direction: column;
    }

    .cycle-image {
      margin-right: 0;
      margin-bottom: 20px;
    }
  }
</style>
</head>
<body>

<?php
// Include the database configuration file
require 'config.php';

if (isset($_GET['Id'])) {
    $product_id = $_GET['Id'];

    // Query the database for the product details
    $sql = "SELECT * FROM main_table WHERE Id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
    } else {
        echo "Product not found.";
        exit();
    }
} else {
    echo "No product ID provided.";
    exit();
}

// Get the brand from the URL query string
$brand = isset($_GET['brand']) ? $_GET['brand'] : '';

?>

<div class="container">
  <div class="cycle-image">
  <img src="../assets/img/<?= $product['IMAGES'] ?>" alt="img">
  </div>
  <div class="cycle-details">
    <h2><u><i><?= $product['CYCLE_NAME']; ?></i></u></h2>
    <p><h4>Old Price: <q style="color: red;"><s>&#8377;<?= $product['OLD_PRICE']; ?></s></q></h4>
    <h4>New Price: <q style="color: blue;">&#8377;<?= $product['NEW_PRICE']; ?></q></h4></p>
    <h2>About Cycle:</h2>
    <div>Details: <?= $product['ABOUT_CYCLE']; ?></div>
    <div class="icon">
      <img src="images/Frame.png" alt="Frame" width="40px" height="40px">
      <strong>Frame Material:</strong> <?= $product['FRAME']; ?>
    </div>
    <div class="icon">
        <img src="images/Fork.png" alt="Fork" width="40px" height="40px">
      <strong>Type:</strong> <?= $product['FORK']; ?> 
    </div>
    <div class="icon">
        <img src="images/Brakes.png" alt="Brakes" width="40px" height="40px">
      <strong>Brakes:</strong> <?= $product['BRAKES']; ?>
    </div>
    <div class="icon">
        <img src="images/Tires.png" alt="Tires" width="40px" height="40px">
      <strong>Tires:</strong> <?= $product['TYRE']; ?>
    </div>
    <div class="icon">
        <img src="images/Rims.png" alt="Rims" width="40px" height="40px">
      <strong>Rims:</strong> <?= $product['RIMS']; ?>
    </div>
    <div class="icon">
        <img src="images/Bottom bracket.png" alt="Bottom Bracket" width="40px" height="40px">
      <strong>Bottom Bracket:</strong> <?= $product['BOTTOM_BRACKET']; ?>
    </div>
    <div class="icon">
        <img src="images/No Of Gears.png" alt="Number of Gears" width="40px" height="40px">
      <strong>Number of Gears:</strong> <?= $product['GEAR']; ?>
    </div>
    <div class="icon">
        <img src="images/Riding Purpose.png" alt="Riding Purpose" width="40px" height="40px">
      <strong>Riding Purpose:</strong> <?= $product['RIDING_PURPOSE']; ?>
    </div>
  </div>
</div>
<?php
            echo '<a href="index.php" class="btn btn-primary mt-3">Back to Avon Products</a>';
        
        ?>
    </div>

</body>
</html>
