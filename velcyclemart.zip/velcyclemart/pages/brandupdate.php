<?php
session_start();
$id = $_SESSION['id'];
include 'config.php';
if (isset($_POST['submit'])){
    $Name = $_POST['Name'];
    $requete = $con -> prepare("UPDATE brand_table 
    SET 
    BRAND_NAME = '$Name'
    WHERE Id = $id");
    $res = $requete -> execute();
    header("location:brand_list.php");
}
?>