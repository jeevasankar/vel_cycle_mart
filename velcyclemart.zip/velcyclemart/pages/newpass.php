<?php
session_start();

if (isset($_POST['submit'])){
    include 'config.php';
    $username = $_POST['username'];
    $email = $_POST['email'];
    $newPassword = $_POST['newPassword'];
    
    $requete = "UPDATE users SET Password = '$newPassword' WHERE username = '$username' and Email = '$email'";
    $statment = $con->prepare($requete);
    $statment->execute();
    
    // Redirect to login page or dashboard
    header("location:sign-in.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
</head>
<body>

<form method="POST">
    <label>New Password:</label>
    <input type="password" name="newPassword" required>
    <input type="hidden" name="username" value="<?php echo $_GET['username']; ?>">
    <input type="hidden" name="email" value="<?php echo $_GET['email']; ?>">
    <button type="submit" name="submit">Submit</button>
</form>

</body>
</html>
