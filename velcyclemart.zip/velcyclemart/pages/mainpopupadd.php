<div class="button-add-">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@mdo">add </button>
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Add products</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                              </div>
                              <div class="modal-body">
                                <form method="POST" action="mainadd.php" enctype="multipart/form-data">
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">img:</label>
                                    <input type="file" class="form-control" id="recipient-name" accept=".jpg,.png,.jpeg" name="IMAGES">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">CYCLE_NAME</label>
                                    <input type="text" class="form-control" id="recipient-name" name="CYCLE_NAME">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">BRAND</label>
                                    <input type="text" class="form-control" id="recipient-name" name="BRAND">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">CATEGORY</label>
                                    <input type="text" class="form-control" id="recipient-name" name="CATEGORY">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">OLD_PRICE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="OLD_PRICE">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">NEW_PRICE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="NEW_PRICE">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">ABOUT_CYCLE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="ABOUT_CYCLE">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">FRAME</label>
                                    <input type="text" class="form-control" id="recipient-name" name="FRAME">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">FORK</label>
                                    <input type="text" class="form-control" id="recipient-name" name="FORK">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">GEAR</label>
                                    <input type="text" class="form-control" id="recipient-name" name="GEAR">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">TYRE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="TYRE">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">BRAKES</label>
                                    <input type="text" class="form-control" id="recipient-name" name="BRAKES">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">RIMS</label>
                                    <input type="text" class="form-control" id="recipient-name" name="RIMS">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">BOTTOM_BRACKET</label>
                                    <input type="text" class="form-control" id="recipient-name" name="BOTTOM_BRACKET">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">RIDING_PURPOSE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="RIDING_PURPOSE">
                                  </div>
                        
                                  <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" name="submit" class="btn btn-primary">add </button>
                              </div>
                                </form>
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>