<?php
session_start();
$id = $_SESSION['id'];
include 'config.php';
if (isset($_POST['submit'])){
    $CYCLE_NAME = $_POST['CYCLE_NAME'];
        $BRAND = $_POST['BRAND'];
        $CATEGORY = $_POST['CATEGORY'];
        $OLD_PRICE = $_POST['OLD_PRICE'];
        $NEW_PRICE = $_POST['NEW_PRICE'];
        $ABOUT_CYCLE = $_POST['ABOUT_CYCLE'];
        $FRAME = $_POST['FRAME'];
        $FORK = $_POST['FORK'];
        $GEAR = $_POST['GEAR'];
        $TYRE = $_POST['TYRE'];
        $BRAKES = $_POST['BRAKES'];
        $RIMS = $_POST['RIMS'];
        $BOTTOM_BRACKET = $_POST['BOTTOM_BRACKET'];
        $RIDING_PURPOSE = $_POST['RIDING_PURPOSE'];
    $requete = $con -> prepare("UPDATE main_table
    SET 
    CYCLE_NAME='$CYCLE_NAME',
    BRAND='$BRAND',
    CATEGORY=' $CATEGORY',
    OLD_PRICE='$OLD_PRICE',
    NEW_PRICE='$NEW_PRICE',
    ABOUT_CYCLE='$ABOUT_CYCLE',
    FRAME='$FRAME',
    FORK='$FORK',
    GEAR='$GEAR',
    TYRE='$TYRE',
    BRAKES='$BRAKES',
    RIMS='$RIMS',
    BOTTOM_BRACKET='$BOTTOM_BRACKET',
    RIDING_PURPOSE='$RIDING_PURPOSE'
    WHERE Id = $id");
    $res = $requete -> execute();
    header("location:main_list.php");
}
?>