<?php
session_start();
include 'config.php';

// Check if ID is set and numeric
if(isset($_GET['Id']) && is_numeric($_GET['Id'])) {
    $_SESSION["id"] = $_GET['Id'];
    $id = $_SESSION["id"];

    // Prepare and execute SQL statement
    $statement = $con->prepare("SELECT * FROM top_cycle_table WHERE Id = ?");
    $statement->bind_param("i", $id);
    $statement->execute();

    // Get the result
    $result = $statement->get_result();

    // Check if the query returned a row
    if($result->num_rows > 0) {
        $table = $result->fetch_assoc();
    } else {
        echo "No record found with the given ID.";
        exit; // Stop further execution
    }
} else {
    echo "Invalid ID provided.";
    exit; // Stop further execution
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Cycle</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="container w-50">
    <form method="POST" action="topcycleupdate.php" enctype="multipart/form-data">
        <div class="form-group">
            <label for="cycle-img" class="col-form-label">Cycle Image:</label>
            <input type="file" class="form-control" id="cycle-img" accept=".jpg,.png,.jpeg" name="IMAGES">
        </div>
        <div class="form-group">
            <label for="cycle-name" class="col-form-label">Cycle Name:</label>
            <input type="text" class="form-control" id="cycle-name" name="CYCLE_NAME" value="<?php echo isset($table['CYCLE_NAME']) ? $table['CYCLE_NAME'] : ''; ?>">
        </div>
        <div class="form-group">
            <label for="brand" class="col-form-label">Brand:</label>
            <input type="text" class="form-control" id="brand" name="BRAND" value="<?php echo isset($table['BRAND']) ? $table['BRAND'] : ''; ?>">
        </div>
        <div class="">
                                    <label for="recipient-name" class="col-form-label">CATEGORY</label>
                                    <input type="text" class="form-control" id="recipient-name" name="CATEGORY" value="<?php echo $table['CATEGORY']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">OLD_PRICE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="OLD_PRICE" value="<?php echo $table['OLD_PRICE']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">NEW_PRICE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="NEW_PRICE" value="<?php echo $table['NEW_PRICE']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">ABOUT_CYCLE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="ABOUT_CYCLE" value="<?php echo $table['ABOUT_CYCLE']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">FRAME</label>
                                    <input type="text" class="form-control" id="recipient-name" name="FRAME" value="<?php echo $table['FRAME']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">FORK</label>
                                    <input type="text" class="form-control" id="recipient-name" name="FORK" value="<?php echo $table['FORK']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">GEAR</label>
                                    <input type="text" class="form-control" id="recipient-name" name="GEAR" value="<?php echo $table['GEAR']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">TYRE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="TYRE" value="<?php echo $table['TYRE']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">BRAKES</label>
                                    <input type="text" class="form-control" id="recipient-name" name="BRAKES" value="<?php echo $table['BRAKES']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">RIMS</label>
                                    <input type="text" class="form-control" id="recipient-name" name="RIMS" value="<?php echo $table['RIMS']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">BOTTOM_BRACKET</label>
                                    <input type="text" class="form-control" id="recipient-name" name="BOTTOM_BRACKET" value="<?php echo $table['BOTTOM_BRACKET']?>">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">RIDING_PURPOSE</label>
                                    <input type="text" class="form-control" id="recipient-name" name="RIDING_PURPOSE" value="<?php echo $table['RIDING_PURPOSE']?>">
                                  </div>
      
        <!-- Submit button -->
        <button type="submit" name="submit" class="btn btn-primary">Update Cycle</button>
    </form>
</div>

<!-- JavaScript and Bootstrap -->
<script src="../js/script.js"></script>
<script src="../js/bootstrap.bundle.js"></script>
</body>
</html>
