<?php 
require 'config.php';
if(isset($_POST['action']))
{
    $sql="SELECT * FROM main_table WHERE BRAND !=''";
    if(isset($_POST['BRAND']))
    {
        $BRAND=implode("','",$_POST['BRAND']); //for converting array to sting
        $sql.="AND BRAND IN('".$BRAND."')";//for checking multiple checkbox
    }
    if(isset($_POST['CATEGORY']))
    {
        $CATEGORY=implode("','",$_POST['CATEGORY']); //for converting array to sting
        $sql.="AND CATEGORY IN('".$CATEGORY."')";//for checking multiple checkbox
    }

    $result=$con->query($sql);
    $output='';
    if($result->num_rows>0)
    {
        while($row=$result->fetch_assoc())
        {
            $output .='<div class="col-md-3 mb-2">
            <div class="card">
                <img src="../assets/img/' . $row['IMAGES'] . '" alt="Product" class="card-img-top" style="object-fit: cover; height: 200px;">
                <div class="card-body">
                    <h5 class="card-title">' . $row['CYCLE_NAME'] . '</h5>
                    <p>Price: ' . number_format($row['NEW_PRICE']) . '/-</p>
                    <p>Category: ' . $row['CATEGORY'] . '</p>
                    <a href="product_details.php?Id=' . $row['Id'] . '&brand=hero" class="btn btn-primary">Product Details</a>
                </div>
            </div>
        </div>';
        
        }
    }
    else
    {
        $output="<h3> No Products Found! </h3>";
    }
    echo $output;
}
?>