<?php 
    include 'config.php';
    $id = $_GET['Id'];

    if(isset($id)){
        $stmt = $con ->prepare("DELETE FROM main_table WHERE Id=$id");
        $stmt -> execute();

    }
    header('location:main_list.php');
?>