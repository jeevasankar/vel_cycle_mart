<?php
session_start(); // Start the session

// Destroy the session and unset all variables
session_unset();
session_destroy();

// Redirect to the sign-in page
header("Location: sign-in.php");
exit();
?>
