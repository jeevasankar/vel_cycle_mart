<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>studens_list</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
</head>

<body class="bg-content">
    <main class="dashboard d-flex">
        <!-- start sidebar -->
        <?php 
            include "component/sidebar.php";
        ?>
        <!-- end sidebar -->

        <!-- start content page -->
        <div class="container-fluid px-4">
        <?php 
            include "component/header.php";
        ?>
          
        
            <!-- start student list table -->
            <div class="student-list-header d-flex justify-content-between align-items-center py-2">
                <div class="title h6 fw-bold">Top cycle list</div>
                <div class="btn-add d-flex gap-3 align-items-center">
                    <div class="short">
                        <i class="far fa-sort"></i>
                    </div>
                    <?php include 'topcyclepopupadd.php'; ?>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table student_list table-borderless">
                    <thead>
                        <tr class="align-middle">
                            <th class="opacity-0">Image</th>
                            <th>Cycle Name</th>
                            <th>Brand</th>
                            <th>Category</th>
                            <th>Old price</th>
                            <th>New price</th>
                            <th>About cycle</th>
                            <th>Frame</th>
                            <th>Fork</th>
                            <th>Gear</th>
                            <th>Tyre</th>
                            <th>Brakes</th>
                            <th>Rims</th>
                            <th>Bottom bracket</th>
                            <th>Riding purpose</th>
                            <th class="opacity-0">list</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                          include 'config.php';
                          $result = $con -> query("SELECT * FROM top_cycle_table");
                          foreach($result as $value):
                        ?>
                      <tr class="bg-white align-middle">
                        <td><img src="../assets/img/<?php echo $value['IMAGES'] ?>" alt="img" height="50" with="50"></td>
                        <td><?php echo $value['CYCLE_NAME'] ?></td>
                        <td><?php echo $value['BRAND'] ?></td>
                        <td><?php echo $value['CATEGORY'] ?></td>
                        <td><?php echo $value['OLD_PRICE'] ?></td>
                        <td><?php echo $value['NEW_PRICE'] ?></td>
                        <td><?php echo $value['ABOUT_CYCLE'] ?></td>
                        <td><?php echo $value['FRAME'] ?></td>
                        <td><?php echo $value['FORK'] ?></td>
                        <td><?php echo $value['GEAR'] ?></td>
                        <td><?php echo $value['TYRE'] ?></td>
                        <td><?php echo $value['BRAKES'] ?></td>
                        <td><?php echo $value['RIMS'] ?></td>
                        <td><?php echo $value['BOTTOM_BRACKET'] ?></td>
                        <td><?php echo $value['RIDING_PURPOSE'] ?></td>
                                <td class="d-md-flex gap-3 mt-3">
                                  <a href="topcyclemodifier.php?Id=<?php echo $value['Id']?>"><i class="far fa-pen"></i></a>
                                  <a href="topcycleremove.php?Id=<?php echo $value['Id']?>"><i class="far fa-trash"></i></a>
                                </td>
                        </tr> 

                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <!-- end student list table -->
        </div>
        <!-- end content page -->
    </main>
    <script src="../js/script.js"></script>
    <script src="../js/bootstrap.bundle.js"></script>
</body>
</html>