<?php 
    include 'config.php';
    $id = $_GET['Id'];

    if(isset($id)){
        $stmt = $con ->prepare("DELETE FROM slider WHERE Id=$id");
        $stmt -> execute();

    }
    header('location:slider_list.php');
?>