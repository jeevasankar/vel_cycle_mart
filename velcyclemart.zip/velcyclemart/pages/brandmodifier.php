<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php
session_start();
include 'config.php';

// Check if Id is set in GET parameters
if(isset($_GET['Id'])) {
    $_SESSION["id"] = $_GET['Id'];
    $id = $_SESSION["id"];

    // Prepare and execute the SQL query
    $statement = $con->prepare("SELECT * FROM brand_table WHERE Id = ?");
    $statement->bind_param("i", $id);
    $statement->execute();

    // Check if the query was successful
    if($result = $statement->get_result()) {
        // Check if any rows were returned
        if($result->num_rows > 0) {
            // Fetch the row as an associative array
            $table = $result->fetch_assoc();
        } else {
            // No rows found, handle this case (e.g., show an error message)
            echo "No data found for the specified Id.";
            exit; // Stop execution
        }
    } else {
        // Query execution failed, handle this case (e.g., show an error message)
        echo "Error executing query: " . $con->error;
        exit; // Stop execution
    }
} else {
    // Id is not set in GET parameters, handle this case (e.g., redirect to a different page)
    echo "Id parameter is missing.";
    exit; // Stop execution
}
?>

<div class="container w-50">


<form method="POST" action="brandupdate.php" enctype="multipart/form-data">
<div class="">
                                    <label for="recipient-name" class="col-form-label">img:</label>
                                    <input type="file" class="form-control" id="recipient-name" accept=".jpg,.png,.jpeg" name="IMAGES">
                                  </div>
                                  <div class="">
                                    <label for="recipient-name" class="col-form-label">Name:</label>
                                    <input type="text" class="form-control" id="recipient-name" name="Name" value="<?php echo $table['BRAND_NAME']?>">
                                  </div>
                                  
                                  <div class="modal-footer">
                                <button type="submit" name="submit" class="btn btn-primary">Update student</button>
                              </div>
                                </form>
</div>
    <script src="../js/script.js"></script>
    <script src="../js/bootstrap.bundle.js"></script>
</body>
</html>




