<?php
session_start();

// Check if the 'email' session variable is not set, redirect to sign-in page
if(empty($_SESSION['email'])) {
    header("Location: sign-in.php");
    exit; // Always good to have an exit after redirection
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
</head>
<body class="bg-content">
    <main class="dashboard d-flex">
        
        <!-- start sidebar -->

       <?php 
            include "component/sidebar.php";
            include 'config.php';
            $nbr_Brands_result = $con->query("SELECT * FROM brand_table");
            $nbr_Brands = mysqli_num_rows($nbr_Brands_result);
            
            $nbr_Category_result = $con->query("SELECT * FROM category_table");
            $nbr_Category = mysqli_num_rows($nbr_Category_result);
            
            $nbr_Products_result = $con->query("SELECT * FROM main_table");
            $nbr_Products = mysqli_num_rows($nbr_Products_result);
            
            $nbr_Users_result = $con->query("SELECT * FROM users");
            $nbr_Users = mysqli_num_rows($nbr_Users_result);
            


        ?>
        <!-- end sidebar -->

        <!-- start content page -->
        <div class="container-fluid px">
        <?php 
            include "component/header.php";
        ?>
            <div class="cards row gap-3 justify-content-center mt-5">
                <div class=" card__items card__items--blue col-md-3 position-relative">
                    <div class="card__Brands d-flex flex-column gap-2 mt-3">
                        <i class="far fa-graduation-cap h3"></i>
                        <span>Brands list</span>
                    </div>
                    <div class="card__nbr-Brands">
                        <span class="h5 fw-bold nbr"><?php echo $nbr_Brands; ?></span>
                    </div>
                </div>

                <div class=" card__items card__items--rose col-md-3 position-relative">
                    <div class="card__Category d-flex flex-column gap-2 mt-3">
                        <i class="fal fa-bookmark h3"></i>
                        <span>category list </span>
                    </div>
                    <div class="card__nbr-Category">
                        <span class="h5 fw-bold nbr"><?php echo $nbr_Category; ?></span>
                    </div>
                </div>

                <div class=" card__items card__items--yellow col-md-3 position-relative">
                    <div class="card__Products d-flex flex-column gap-2 mt-3">
                        <i class="fal fa-usd-square h3"></i>
                        <span>Products list</span>
                    </div>
                    <div class="card__Products">
                    <span class="h5 fw-bold nbr"><?php echo $nbr_Products; ?></span>
                    </div>
                </div>

                <div class="card__items card__items--gradient col-md-3 position-relative">
                    <div class="card__users d-flex flex-column gap-2 mt-3">
                        <i class="fal fa-user h3"></i>
                        <span>Users</span>
                    </div>
                    <div class="card__Users">
                    <span class="h5 fw-bold nbr"><?php echo $nbr_Users; ?></span>
                    </div>
                </div>

        </div>
        <!-- end contentpage -->
    </main>
    <script src="../js/script.js"></script>
    <script src="/js/bootstrap.bundle.js"></script>
</body>

</html>