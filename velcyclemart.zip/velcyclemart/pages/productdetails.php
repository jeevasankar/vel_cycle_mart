<?php
// Include the database configuration file
require 'config.php';

if (isset($_GET['Id'])) {
    $product_id = $_GET['Id'];

    // Query the database for the product details
    $sql = "SELECT * FROM main_table WHERE Id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
    } else {
        echo "Product not found.";
        exit();
    }
} else {
    echo "No product ID provided.";
    exit();
}

// Get the brand from the URL query string
$brand = isset($_GET['brand']) ? $_GET['brand'] : '';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h1 class="mt-5">Product Details</h1>
        
        <!-- Display product details -->
        <div class="card mt-3">
            <img src="<?= $product['IMAGES']; ?>" alt="<?= $product['CYCLE_NAME']; ?>" class="card-img-top" style="object-fit: cover; height: 300px;">
            <div class="card-body">
                <h3 class="card-title"><?= $product['CYCLE_NAME']; ?></h3>
                <p class="card-text"><strong>Price:</strong> <?= number_format($product['NEW_PRICE']); ?>/-</p>
                <p class="card-text"><strong>Category:</strong> <?= $product['CATEGORY']; ?></p>
                <p class="card-text"><strong>Brand:</strong> <?= $product['BRAND']; ?></p>
                <!-- Add any other product details you want to display -->
            </div>
        </div>
        
        <!-- Back button to navigate back to the brand page -->
        <?php
        // Create the back button link based on the brand
        if ($brand === 'avon') {
            echo '<a href="avon.php" class="btn btn-primary mt-3">Back to Avon Products</a>';
        } elseif ($brand === 'hero') {
            echo '<a href="hero.php" class="btn btn-primary mt-3">Back to Hero Products</a>';
        } elseif ($brand === 'hercules') {
            echo '<a href="hercules.php" class="btn btn-primary mt-3">Back to Hercules Products</a>';
        } else {
            echo '<a href="index.php" class="btn btn-primary mt-3">Back to Product List</a>';
        }
        ?>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>