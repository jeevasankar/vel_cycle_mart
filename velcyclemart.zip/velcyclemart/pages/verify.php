<?php
session_start();
require 'config.php';

if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $password = $_POST['pass'];

    // Use prepared statements to prevent SQL injection
    $stmt = $con->prepare("SELECT * FROM users WHERE Email = ? AND Password = ?");
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // User found, set session and redirect to dashboard
        $row = $result->fetch_assoc();
        $_SESSION['name'] = $row['username'];
        $_SESSION['email'] = $row['Email']; // Set email in session for verification
        header("location: dashboard.php");
        exit; // Always good to have an exit after redirection
    } else {
        // User not found or incorrect credentials
        header("location: sign-in.php?error=invalid_credentials");
        exit; // Always good to have an exit after redirection
    }
} else {
    // Handle the case if the submit button was not pressed
    header("location: sign-in.php?error=submit_button_not_pressed");
    exit; // Always good to have an exit after redirection
}
?>
