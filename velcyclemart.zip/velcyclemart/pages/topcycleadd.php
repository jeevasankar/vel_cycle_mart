<?php 
    include 'conixion.php';
    if(isset($_POST['submit'])){
        
        $image = $_FILES['IMAGES']['name'];
        $tempname = $_FILES['IMAGES']['tmp_name'];  
        $folder = "../assets/img/".$image;
        
        if(move_uploaded_file($tempname,$folder)){
            echo 'images est uplade';
        }

        
        $CYCLE_NAME = $_POST['CYCLE_NAME'];
        $BRAND = $_POST['BRAND'];
        $CATEGORY = $_POST['CATEGORY'];
        $OLD_PRICE = $_POST['OLD_PRICE'];
        $NEW_PRICE = $_POST['NEW_PRICE'];
        $ABOUT_CYCLE = $_POST['ABOUT_CYCLE'];
        $FRAME = $_POST['FRAME'];
        $FORK = $_POST['FORK'];
        $GEAR = $_POST['GEAR'];
        $TYRE = $_POST['TYRE'];
        $BRAKES = $_POST['BRAKES'];
        $RIMS = $_POST['RIMS'];
        $BOTTOM_BRACKET = $_POST['BOTTOM_BRACKET'];
        $RIDING_PURPOSE = $_POST['RIDING_PURPOSE'];
        
        $requete = $con->prepare("INSERT INTO top_cycle_table(IMAGES,CYCLE_NAME,BRAND,CATEGORY,OLD_PRICE,NEW_PRICE,ABOUT_CYCLE,FRAME,FORK,GEAR,TYRE,BRAKES,RIMS,BOTTOM_BRACKET,RIDING_PURPOSE) 
        VALUES('$image','$CYCLE_NAME','$BRAND','$CATEGORY','$OLD_PRICE','$NEW_PRICE','$ABOUT_CYCLE','$FRAME','$FORK','$GEAR','$TYRE','$BRAKES','$RIMS','$BOTTOM_BRACKET','$RIDING_PURPOSE')");
        //$requete->execute(array($image,$Name,$Email,$Phone,$EnrollNumber,$DateOfAdmission));
        $requete->execute();
    }
    header('location:topcycle_list.php')
    ?>