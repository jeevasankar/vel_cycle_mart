<?php
session_start();
if(isset($_POST['submit'])){
    include 'config.php';
    $email = $_POST['email'];
    $password = $_POST['pass'];

    // Use prepared statements to prevent SQL injection
    $query = "SELECT * FROM users WHERE Email = ?";
    $statement = $con->prepare($query);
    $statement->bind_param("s", $email);
    $statement->execute();
    $result = $statement->get_result()->fetch_assoc();

    if($result) {
        // Verify the password
        if(password_verify($password, $result['Password'])){
            $_SESSION['name'] = $result['username'];
            $_SESSION['email'] = $result['Email'];
            // Don't store password in session
            if(isset($_POST['check'])){
                setcookie('email', $_SESSION['email'], time() + 3600);
                // You shouldn't store passwords in cookies for security reasons
            }
            header("location:dashboard.php");
        } else {
            header("location:sign-in.php?error=email or password not found");
        }
    } else {
        header("location:sign-in.php?error=please enter your email or password");
    }
}
?>
