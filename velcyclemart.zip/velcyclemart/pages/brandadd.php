<?php 
    include 'config.php';
    if(isset($_POST['submit'])){
        $image = $_FILES['IMAGES']['name'];
        $tempname = $_FILES['IMAGES']['tmp_name'];  
        $folder = "../assets/img/".$image;
        
        if(move_uploaded_file($tempname,$folder)){
            echo 'images est uplade';
        }  
    
        $Name = $_POST['BRAND'];

        $requete = $con->prepare("INSERT INTO brand_table(BRAND_NAME,IMAGES) VALUES('$Name','$image')");
        //$requete->execute(array($image,$Name,$Email,$Phone,$EnrollNumber,$DateOfAdmission));
        $requete->execute();
    }
    header('location:brand_list.php')
    ?>
