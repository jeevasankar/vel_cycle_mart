<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filter Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }
        .container {
            display: flex;
            justify-content: space-between;
            max-width: 1300px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .filter-container {
            flex-basis: 20%;
        }
        .product-container {
            flex-basis: 80%;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        h2 {
            text-align: center;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
        }
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        input[type="submit"] {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .product-card {
            flex-basis: calc(33.33% - 20px); /* Adjust width as needed */
            margin-bottom: 20px;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
        }
        .product-card img {
            max-width: 100%;
            height: auto;
        }

        /* Added styles for custom product card */
        .container1 {
            width: 100%;
            max-width: 300px; /* Adjust as needed */
            margin: 20px;
        }

        .card1 {
            width: 100%;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: rgba(136, 165, 191, 0.48) 6px 2px 16px 0px, rgba(255, 255, 255, 0.8) -6px -2px 16px 0px;
            transition: transform 0.3s ease;
        }

        .card1:hover {
            transform: translateY(-5px);
        }

        .card1 img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
        }

        .card-body1 {
            padding: 20px;
        }

        .card-body1 p {
            color: #3d3d3d;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .view-btn1 a {
            padding: 8px 20px;
            border: 1.5px solid #007bff;
            border-radius: 3px;
            text-decoration: none;
            color: #007bff;
            transition: background-color 0.3s, color 0.3s;
        }

        .view-btn1 a:hover {
            color: #fff;
            background-color: #007bff;
        }

        .btn-group1 {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .button-29 {
            appearance: none;
            background-image: radial-gradient(100% 100% at 100% 0, #5adaff 0, #5468ff 100%);
            border: 0;
            border-radius: 6px;
            box-shadow: rgba(45, 35, 66, .4) 0 2px 4px, rgba(45, 35, 66, .3) 0 7px 13px -3px, rgba(58, 65, 111, .5) 0 -3px 0 inset;
            color: #fff;
            cursor: pointer;
            font-family: "JetBrains Mono", monospace;
            font-size: 18px;
            height: 48px;
            line-height: 1;
            overflow: hidden;
            padding: 0 16px;
            position: relative;
            text-align: center;
            text-decoration: none;
            transition: box-shadow 0.15s, transform 0.15s;
            user-select: none;
            white-space: nowrap;
            width: 100%;
        }

        .button-29:focus {
            box-shadow: #3c4fe0 0 0 0 1.5px inset, rgba(45, 35, 66, .4) 0 2px 4px, rgba(45, 35, 66, .3) 0 7px 13px -3px, #3c4fe0 0 -3px 0 inset;
        }

        .button-29:hover {
            box-shadow: rgba(45, 35, 66, .4) 0 4px 8px, rgba(45, 35, 66, .3) 0 7px 13px -3px, #3c4fe0 0 -3px 0 inset;
            transform: translateY(-2px);
        }

        .button-29:active {
            box-shadow: #3c4fe0 0 3px 7px inset;
            transform: translateY(2px);
        }

        .credit1 a {
            text-decoration: none;
            color: #000;
            font-weight: 800;
        }

        .credit1 {
            color: #000;
            text-align: center;
            margin-top: 10px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        @media screen and (max-width: 768px) {
            .container1 {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="filter-container">
            <h2>Filters</h2>
            <form method="post">
                <label for="category">Category:</label><br>
                <?php echo generateCheckboxes("CATEGORY[]", "category"); ?><br><br>

                <label for="brand">Brand:</label><br>
                <?php echo generateCheckboxes("BRAND[]", "brand"); ?><br><br>

                <input type="submit" name="submit" value="Filter">
            </form>
        </div>

        <div class="product-container">
            <?php
            // Establishing connection to the database
            // $con = mysqli_connect("localhost", "root", "", "vels_cycle_mart");
            // if (!$con) {
            //     echo "Connection Failed: " . mysqli_connect_error();
            // }
            include "component/header.php";
            // Fetch data based on filter criteria
            $filters = array();
            if (isset($_POST['submit'])) {
                // Add filter criteria
                if (!empty($_POST['CATEGORY'])) {
                    $filters['CATEGORY'] = $_POST['CATEGORY'];
                }
                if (!empty($_POST['BRAND'])) {
                    $filters['BRAND'] = $_POST['BRAND'];
                }

                // Generate filter query
                $filterQuery = generateFilterQuery($filters);

                // Execute the query
                $result = mysqli_query($con, $filterQuery);

                // Check if any results are fetched
                if (mysqli_num_rows($result) > 0) {
                    // Output data of each row
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<div class='container1'>";
                        echo "<div class='card1'>";
                        echo "<img src='../assets/img/{$row['IMAGES']}' alt='' />";
                        echo "<div class='card-body1'>";
                        echo "<div class='row1'>";
                        echo "<div class='card-title1'>";
                        echo "<h4>{$row['CYCLE_NAME']}</h4>";
                        echo "<h3>{$row['PRICE']}</h3>";
                        echo "</div>";
                        echo "</div>";
                        echo "<hr/>";
                        echo "<p>{$row['DESCRIPTION']}</p>";
                        echo "<div class='btn-group1'>";
                        echo "<a href='../pages/index.php' class='button-link'>";
                        echo "<button class='button-29' role='button1'>Buy Now</button>";
                        echo "</a>";
                        echo "</div>";
                        echo "</div>";
                        echo "</div>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No products found.</p>";
                }
            }

            // Close the database connection
            mysqli_close($con);

            // Function to generate the filter query based on user input
            function generateFilterQuery($filters) {
                $filterQuery = "SELECT * FROM main_table WHERE 1";

                // Check if any filters are applied
                if (!empty($filters)) {
                    foreach ($filters as $key => $values) {
                        $filterQuery .= " AND $key IN ('" . implode("','", $values) . "')";
                    }
                }

                return $filterQuery;
            }

            // Function to generate checkboxes for select dropdowns
            function generateCheckboxes($name, $columnName) {
                // Establishing connection to the database
                $con = mysqli_connect("localhost", "root", "", "vels_cycle_mart");
                if (!$con) {
                    echo "Connection Failed: " . mysqli_connect_error();
                }

                // Query to fetch unique values and their count from the column
                $query = "SELECT $columnName, COUNT(*) AS count FROM main_table GROUP BY $columnName";

                // Execute the query
                $result = mysqli_query($con, $query);

                // Initialize checkboxes string
                $checkboxes = "";

                // Add checkboxes for each value
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $checkboxes .= "<input type='checkbox' name='$name' value='{$row[$columnName]}'>{$row[$columnName]} ({$row['count']})<br>";
                    }
                }

                // Close the database connection
                mysqli_close($con);

                return $checkboxes;
            }
            ?>
        </div>
    </div>
</body>
</html>
