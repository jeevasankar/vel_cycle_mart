<?php
session_start();
$id = $_SESSION['id'];
include 'config.php';
if (isset($_POST['submit'])){
    $Name = $_POST['Name'];
    $requete = $con -> prepare("UPDATE category_table 
    SET 
    CATEGORY = '$Name'
    WHERE Id = $id");
    $res = $requete -> execute();
    header("location:category_list.php");
}
?>