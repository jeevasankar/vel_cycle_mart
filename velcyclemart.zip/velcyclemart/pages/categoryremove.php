<?php 
    include 'config.php';
    $id = $_GET['Id'];

    if(isset($id)){
        $stmt = $con ->prepare("DELETE FROM category_table WHERE Id=$id");
        $stmt -> execute();

    }
    header('location:category_list.php');
?>