-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2024 at 09:51 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vels_cycle_mart`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand_table`
--

CREATE TABLE `brand_table` (
  `Id` int(11) NOT NULL,
  `BRAND_NAME` varchar(50) NOT NULL,
  `TOTAL_PRODUCT` int(50) NOT NULL,
  `IMAGES` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brand_table`
--

INSERT INTO `brand_table` (`Id`, `BRAND_NAME`, `TOTAL_PRODUCT`, `IMAGES`) VALUES
(19, 'HERO', 0, 'HERO.png'),
(20, 'HERCULES', 0, 'HERCULES.png'),
(29, 'AVON', 0, 'AVON.png'),
(38, 'wertg', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `category_table`
--

CREATE TABLE `category_table` (
  `Id` int(11) NOT NULL,
  `CATEGORY` varchar(50) NOT NULL,
  `TOTAL_CATEGORY` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category_table`
--

INSERT INTO `category_table` (`Id`, `CATEGORY`, `TOTAL_CATEGORY`) VALUES
(1, 'MENS', 0),
(8, 'WOMENS', 0),
(9, 'KIDS', 0);

-- --------------------------------------------------------

--
-- Table structure for table `main_table`
--

CREATE TABLE `main_table` (
  `Id` int(11) NOT NULL,
  `CYCLE_NAME` varchar(100) NOT NULL,
  `BRAND` varchar(100) NOT NULL,
  `CATEGORY` varchar(100) NOT NULL,
  `OLD_PRICE` int(50) NOT NULL,
  `NEW_PRICE` int(50) NOT NULL,
  `ABOUT_CYCLE` varchar(500) NOT NULL,
  `FRAME` varchar(50) NOT NULL,
  `FORK` varchar(50) NOT NULL,
  `GEAR` varchar(50) NOT NULL,
  `TYRE` varchar(50) NOT NULL,
  `BRAKES` varchar(50) NOT NULL,
  `RIMS` varchar(50) NOT NULL,
  `BOTTOM_BRACKET` varchar(50) NOT NULL,
  `RIDING_PURPOSE` varchar(50) NOT NULL,
  `IMAGES` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `main_table`
--

INSERT INTO `main_table` (`Id`, `CYCLE_NAME`, `BRAND`, `CATEGORY`, `OLD_PRICE`, `NEW_PRICE`, `ABOUT_CYCLE`, `FRAME`, `FORK`, `GEAR`, `TYRE`, `BRAKES`, `RIMS`, `BOTTOM_BRACKET`, `RIDING_PURPOSE`, `IMAGES`) VALUES
(14, 'HUSTLE', 'HERO', 'ALL', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero HUSTLE.png'),
(16, 'Hero CyclesBLUNT', 'HERO', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero CyclesBLUNT.png'),
(17, 'Hero CyclesTEJAS SPORTS 26T', 'HERO', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero CyclesTEJAS SPORTS 26T.png'),
(18, 'Hero CyclesTHORN', 'HERO', 'WOMENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero CyclesTHORN.png'),
(19, 'Hero SprintHOWLER 2.0.png', 'HERO', 'KIDS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero SprintHOWLER 2.0.png'),
(20, 'NEW ATTITUDE', 'HERO', 'KIDS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'NEW ATTITUDE.png'),
(21, 'KINGS SINGLE SPEED', 'AVON', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'KINGS SINGLE SPEED.png'),
(22, 'KINGS SINGLE SPEED', 'AVON', 'KIDS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'KINGS SINGLE SPEED.png'),
(23, 'ACID 27.5T.PNG', 'AVON', 'WOMENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'ACID 27.5T.PNG'),
(24, 'BALVEER 28T.png', 'AVON', 'ALL', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'BALVEER 28T.png'),
(25, 'cyclelec-connect-unisex-26t.png', 'AVON', 'WOMENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'cyclelec-connect-unisex-26t.png'),
(26, 'GAMER X.png', 'AVON', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'GAMER X.png'),
(27, 'Hercules Streetcat Pro IC HT DX2 26T Ferrari Red', 'HERCULES', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hercules Streetcat Pro IC HT DX2 26T Ferrari Red.png'),
(28, 'Hercules Dynamite ZX 26T Green and Orange.png', 'HERCULES', 'WOMENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hercules Dynamite ZX 26T Green and Orange.png'),
(29, 'Hercules Streetcat Pro HT DX2 26T Ferrari Red', 'HERCULES', 'KIDS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hercules Streetcat Pro HT DX2 26T Ferrari Red.png'),
(30, 'Hercules Streetcat Pro IC HT DX2 26T Cactus Green', 'HERCULES', 'ALL', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hercules Streetcat Pro IC HT DX2 26T Cactus Green.png'),
(31, 'HUSTLE', 'HERO', 'ALL', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero HUSTLE.png'),
(32, 'Hero CyclesBLUNT', 'HERO', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero CyclesBLUNT.png'),
(33, 'Hero CyclesTEJAS SPORTS 26T', 'HERO', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero CyclesTEJAS SPORTS 26T.png'),
(34, 'Hero CyclesTHORN', 'HERO', 'WOMENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero CyclesTHORN.png'),
(35, 'Hero SprintHOWLER 2.0.png', 'HERO', 'KIDS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero SprintHOWLER 2.0.png'),
(36, 'NEW ATTITUDE', 'HERO', 'KIDS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'NEW ATTITUDE.png'),
(37, 'KINGS SINGLE SPEED', 'AVON', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'KINGS SINGLE SPEED.png'),
(38, 'KINGS SINGLE SPEED', 'AVON', 'KIDS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'KINGS SINGLE SPEED.png'),
(39, 'ACID 27.5T.PNG', 'AVON', 'WOMENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'ACID 27.5T.PNG'),
(40, 'BALVEER 28T.png', 'AVON', 'ALL', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'BALVEER 28T.png'),
(41, 'cyclelec-connect-unisex-26t.png', 'AVON', 'WOMENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'cyclelec-connect-unisex-26t.png'),
(42, 'GAMER X.png', 'AVON', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'GAMER X.png'),
(43, 'Hercules Streetcat Pro IC HT DX2 26T Ferrari Red', 'HERCULES', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hercules Streetcat Pro IC HT DX2 26T Ferrari Red.png'),
(44, 'Hercules Dynamite ZX 26T Green and Orange.png', 'HERCULES', 'WOMENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hercules Dynamite ZX 26T Green and Orange.png'),
(45, 'Hercules Streetcat Pro HT DX2 26T Ferrari Red', 'HERCULES', 'KIDS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hercules Streetcat Pro HT DX2 26T Ferrari Red.png'),
(46, 'Hercules Streetcat Pro IC HT DX2 26T Cactus Green', 'HERCULES', 'ALL', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hercules Streetcat Pro IC HT DX2 26T Cactus Green.png'),
(47, 'ACID', 'jeeva', 'gh', 1242, 85452, 'dxcygujhbknl/l.', 'rytfugihjk;l', '', '', '', '', '', '', '', 'ACID 27.5T.PNG'),
(48, '', 'gkfgvhbjnkml,', '  ', 0, 0, '', '', '', '', '', '', '', '', '', ''),
(49, 'JEEVA', 'JEEVA', '', 0, 0, '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `Id` int(10) NOT NULL,
  `slider_name` varchar(225) NOT NULL,
  `IMAGES` varchar(225) NOT NULL,
  `slider_url` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`Id`, `slider_name`, `IMAGES`, `slider_url`) VALUES
(8, '', 'banner-1.jpg', ''),
(9, '', 'banner-2.jpg', ''),
(10, '', 'banner-3.png', '');

-- --------------------------------------------------------

--
-- Table structure for table `top_cycle_table`
--

CREATE TABLE `top_cycle_table` (
  `Id` int(11) NOT NULL,
  `CYCLE_NAME` varchar(100) NOT NULL,
  `BRAND` varchar(100) NOT NULL,
  `CATEGORY` varchar(100) NOT NULL,
  `OLD_PRICE` int(50) NOT NULL,
  `NEW_PRICE` int(50) NOT NULL,
  `ABOUT_CYCLE` varchar(500) NOT NULL,
  `FRAME` varchar(50) NOT NULL,
  `FORK` varchar(50) NOT NULL,
  `GEAR` varchar(50) NOT NULL,
  `TYRE` varchar(50) NOT NULL,
  `BRAKES` varchar(50) NOT NULL,
  `RIMS` varchar(50) NOT NULL,
  `BOTTOM_BRACKET` varchar(50) NOT NULL,
  `RIDING_PURPOSE` varchar(50) NOT NULL,
  `IMAGES` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `top_cycle_table`
--

INSERT INTO `top_cycle_table` (`Id`, `CYCLE_NAME`, `BRAND`, `CATEGORY`, `OLD_PRICE`, `NEW_PRICE`, `ABOUT_CYCLE`, `FRAME`, `FORK`, `GEAR`, `TYRE`, `BRAKES`, `RIMS`, `BOTTOM_BRACKET`, `RIDING_PURPOSE`, `IMAGES`) VALUES
(14, 'HUSTLE', 'HERO', 'ALL', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero HUSTLE.png'),
(16, 'Hero CyclesBLUNT', 'HERO', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero CyclesBLUNT.png'),
(17, 'Hero CyclesTEJAS SPORTS 26T', 'HERO', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero CyclesTEJAS SPORTS 26T.png'),
(18, 'Hero CyclesTHORN', 'HERO', 'WOMENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero CyclesTHORN.png'),
(19, 'Hero SprintHOWLER 2.0.png', 'HERO', 'KIDS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hero SprintHOWLER 2.0.png'),
(20, 'NEW ATTITUDE', 'HERO', 'KIDS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'NEW ATTITUDE.png'),
(21, 'KINGS SINGLE SPEED', 'AVON', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'KINGS SINGLE SPEED.png'),
(22, 'KINGS SINGLE SPEED', 'AVON', 'KIDS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'KINGS SINGLE SPEED.png'),
(23, 'ACID 27.5T.PNG', 'AVON', 'WOMENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'ACID 27.5T.PNG'),
(24, 'BALVEER 28T.png', 'AVON', 'ALL', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'BALVEER 28T.png'),
(25, 'cyclelec-connect-unisex-26t.png', 'AVON', 'WOMENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'cyclelec-connect-unisex-26t.png'),
(26, 'GAMER X.png', 'AVON', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'GAMER X.png'),
(27, 'Hercules Streetcat Pro IC HT DX2 26T Ferrari Red', 'HERCULES', 'MENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hercules Streetcat Pro IC HT DX2 26T Ferrari Red.png'),
(28, 'Hercules Dynamite ZX 26T Green and Orange.png', 'HERCULES', 'WOMENS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hercules Dynamite ZX 26T Green and Orange.png'),
(29, 'Hercules Streetcat Pro HT DX2 26T Ferrari Red', 'HERCULES', 'KIDS', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hercules Streetcat Pro HT DX2 26T Ferrari Red.png'),
(30, 'Hercules Streetcat Pro IC HT DX2 26T Cactus Green', 'HERCULES', 'ALL', 16000, 14000, 'Life is a hustle. But with the Hero Sprint Hustle, you can make it infinitely better. Equipped with SPUR suspensions, a mechanical disc braking system, and the revolutionary GEMTEC™, your cruising experience is all set to reach its absolute pinnacle. Hustle hard, this cycle has got your back!', 'Hi-Tensile Steel', 'Spur', 'Shimano', '26T X 2.40', 'Mechanical Disc', 'PU with Alloy QR', 'Dual Disc', 'All', 'Hercules Streetcat Pro IC HT DX2 26T Cactus Green.png');

-- --------------------------------------------------------

--
-- Table structure for table `top_picks_table`
--

CREATE TABLE `top_picks_table` (
  `Id` int(11) NOT NULL,
  `CYCLE_NAME` varchar(100) NOT NULL,
  `BRAND` varchar(100) NOT NULL,
  `CATEGORY` varchar(100) NOT NULL,
  `OLD_PRICE` int(50) NOT NULL,
  `NEW_PRICE` int(50) NOT NULL,
  `ABOUT_CYCLE` varchar(500) NOT NULL,
  `FRAME` varchar(50) NOT NULL,
  `FORK` varchar(50) NOT NULL,
  `GEAR` varchar(50) NOT NULL,
  `TYRE` varchar(50) NOT NULL,
  `BRAKES` varchar(50) NOT NULL,
  `RIMS` varchar(50) NOT NULL,
  `BOTTOM_BRACKET` varchar(50) NOT NULL,
  `RIDING_PURPOSE` varchar(50) NOT NULL,
  `IMAGES` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `Email`, `Password`) VALUES
(1, 'sabir', 'sabir@gmail.com', 'Sabir123'),
(2, 'jeeva', 'jeevakamalam123@gmail.com', '987654321'),
(3, 'jeevasankar', 'jeevasankar321@gmail.com', '123456789'),
(5, '21ECR110', 'kishoreanandr.21ece@kongu.edu', 'Kishore@04'),
(6, 'jeevasankar', 'abc@gmail.com', '12345'),
(7, 'kishore', 'kishoreanand.r@gmail.com', 'qwer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand_table`
--
ALTER TABLE `brand_table`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `category_table`
--
ALTER TABLE `category_table`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `main_table`
--
ALTER TABLE `main_table`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `top_cycle_table`
--
ALTER TABLE `top_cycle_table`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brand_table`
--
ALTER TABLE `brand_table`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `category_table`
--
ALTER TABLE `category_table`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `main_table`
--
ALTER TABLE `main_table`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `top_cycle_table`
--
ALTER TABLE `top_cycle_table`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
