<?php
    require 'config.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vel cycle Mart</title>

  <!-- 
    - favicon
  -->
  <link rel="shortcut icon" href="./favicon.svg" type="image/svg+xml">

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/style.css">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&family=Poppins:wght@400;500;600;700&display=swap"
    rel="stylesheet">
</head>

<body>

  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>

    <div class="overlay" data-overlay></div>

    <div class="header-top">
      <div class="container">

        <ul class="header-top-list">

        <li>
            <a href="#" class="header-top-link" style="padding:10px;">
              <span style="font-size:20px;">VEL CYCLE MART</span>
            </a>
          </li>

          

        </ul>

      
      </div>
    </div>

    <div class="header-bottom">
      <div class="container">

        <a href="index.php" class="logo" id="menulogo" style="color:#ffa343;font-weight:900;"><b>VEL CYCLE MART</b>
        </a>

        <nav class="navbar" data-navbar>

          <div class="navbar-top">

            <a href="#" class="logo">
              <img src="./assets/images/logo.png" alt="Homeverse logo">
            </a>

            <button class="nav-close-btn" data-nav-close-btn aria-label="Close Menu">
              <ion-icon name="close-outline"></ion-icon>
            </button>

          </div>

          <div class="navbar-bottom">
            <ul class="navbar-list">

              <li>
                <a href="#" class="navbar-link" data-nav-link>Home</a>
              </li>

              <li>
                <a href="#about" class="navbar-link" data-nav-link>About</a>
              </li>

              <li>
                <a href="#service" class="navbar-link" data-nav-link>Brand</a>
              </li>

              <li>
                <a href="#property" class="navbar-link" data-nav-link>Top Products</a>
              </li>

              <li>
                <a href="filter.php" class="navbar-link" data-nav-link>All Products</a>
              </li>

              <!-- <li>
                <a href="#contact" class="navbar-link" data-nav-link>Contact</a>
              </li> -->

            </ul>
          </div>

        </nav>

        <div class="header-bottom-actions">

          <button class="header-bottom-actions-btn" aria-label="Profile">
          <a href="../pages/sign-in.php">
    <ion-icon name="person-outline"></ion-icon>
    </a>

            <span>Admin</span>
          </button>


          <button class="header-bottom-actions-btn" data-nav-open-btn aria-label="Open Menu">
            <ion-icon name="menu-outline"></ion-icon>

            <span>Menu</span>
          </button>

        </div>

      </div>
    </div>

  </header>





  <main>
    <article>

      <div class="slideshow-container">
    <?php
            $sql="SELECT * FROM slider";
            $result=$con->query($sql);
            while($row=$result->fetch_assoc())
            {
        ?>

        <div class="mySlides fade">
            <img src="../assets/img/<?php echo $row['IMAGES'] ?>" style="width:100%">
            <div class="text1"><?= $row['slider_name']; ?></div>
        </div>
        <?php } ?>
            <a class="prev" onclick="plusSlides(-1)">❮</a>
            <a class="next" onclick="plusSlides(1)">❯</a>

    </div>
    <br>
        <div style="text-align:center">
            <span class="dot" onclick="currentSlide(1)"></span> 
            <span class="dot" onclick="currentSlide(2)"></span> 
            <span class="dot" onclick="currentSlide(3)"></span> 
        </div>

    <script>
        let slideIndex = 1;
        showSlides(slideIndex);

        function plusSlides(n) {
        showSlides(slideIndex += n);
        }

        function currentSlide(n) {
         showSlides(slideIndex = n);
        }

        function showSlides(n) {
        let i;
         let slides = document.getElementsByClassName("mySlides");
        let dots = document.getElementsByClassName("dot");
        if (n > slides.length) {slideIndex = 1}    
        if (n < 1) {slideIndex = slides.length}
        for (i = 0; i < slides.length; i++) {
              slides[i].style.display = "none";  
        }
        for (i = 0; i < dots.length; i++) {
             dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex-1].style.display = "block";  
        dots[slideIndex-1].className += " active";
        }
    </script>





      <!-- 
        - #ABOUT
      -->

      <section class="about" id="about">
        <div class="container">

          <figure class="about-banner">
            <img src="./assets/images/about-2.png" alt="House interior">

          </figure>

          <div class="about-content">

            <p class="section-subtitle">About Us</p>

            <h2 class="h2 section-title">
                Vel Cycle Mart</h2>

            <p class="about-text">
            Wholesaler of kids bicycle, bicycle frames & hybrid bicycle since 1960 in Namakkal, Tamil Nadu.
            </p>

            <ul class="about-list">

              <li class="about-item">
                <div class="about-item-icon">
                  <ion-icon name="cart-outline"></ion-icon>
                </div>

                <p class="about-item-text"><b>Nature of Business</b>:  Wholesaler</p>
              </li>

              <li class="about-item">
                <div class="about-item-icon">
                  <ion-icon name="business-outline"></ion-icon>
                </div>

                <p class="about-item-text"><b>Year of Establishment</b>:  1960</p>
              </li>

              <li class="about-item">
                <div class="about-item-icon">
                  <ion-icon name="document-outline"></ion-icon>
                </div>

                <p class="about-item-text"><b>GST Number:</b>  33APUPK5908E1ZQ</p>
              </li>

              <li class="about-item">
                <div class="about-item-icon">
                  <ion-icon name="people-outline"></ion-icon>
                </div>

                <p class="about-item-text"><b>Total Number of Employees:</b>   11 to 25 People</p>
              </li>
              <li class="about-item">
                <div class="about-item-icon">
                  <ion-icon name="briefcase-outline"></ion-icon>
                </div>

                <p class="about-item-text"><b>Legal Status of Firm:</b>   Individual - Proprietor</p>
              </li>

            </ul>

            <p class="callout">
              "If you have any suggestions/recommendations or queries Contact Us"
            </p>

            <!-- <a href="#service" class="btn">Contact Us</a> -->

          </div>

        </div>
      </section>





      <!-- 
        - #SERVICE
      -->

      <section class="service" id="service">
        <div class="container">

          <p class="section-subtitle">Brands</p>

          <h2 class="h2 section-title">Our Top Brands</h2>

          <ul class="service-list">
          <?php
            $sql="SELECT * FROM brand_table";
            $result=$con->query($sql);
            while($row=$result->fetch_assoc())
            {
              ?>

            <li>
            
              <div class="service-card">

                <div class="card-icon">
                  <img src="../assets/img/<?php echo $row['IMAGES'] ?>" alt="Service icon" width="150" height="150">
                </div>

                <h3 class="h3 card-title">
                  <a href="#"><?php echo $row['BRAND_NAME'] ?></a>
                </h3>

             

              </div>
            </li>
            <?php } ?>


          </ul>

        </div>
      </section>





      <!-- 
        - #PROPERTY
      -->

      <section class="property" id="property">
        <div class="container">

          <p class="section-subtitle">TOP PICKS</p>

          <h2 class="h2 section-title">Our Most Popular Products!</h2>

          <ul class="property-list has-scrollbar">
            <?php
              $sql="SELECT * FROM top_cycle_table";
              $result=$con->query($sql);
              while($row=$result->fetch_assoc())
              {
              ?>

            <li>
              <div class="property-card">

                <figure class="card-banner">

                  <a >
                    <img src="../assets/img/<?php echo $row['IMAGES'] ?>" alt="New Apartment Nice View" class="w-100">
                  </a>

                  <div class="card-badge green">Top Cycles</div>

                  <div class="banner-actions">

                    <button class="banner-actions-btn">
                      <ion-icon name="pin"></ion-icon>

                      <address><h2>BRAND:</h2><h4> <?php echo $row['BRAND'] ?></h4></address>
                    </button>

                    <button class="banner-actions-btn">
                      <ion-icon name="apps-outline"></ion-icon>

                      <span><h2>CATEGORY: </h2><h4><?php echo $row['CATEGORY'] ?></h4></span>
                    </button>

                  </div>

                </figure>

                <div class="card-content">

                  <div class="card-price">
                    <strong>&#8377;<?= $row['NEW_PRICE']; ?></strong>/<s>&#8377;<?= $row['OLD_PRICE']; ?></s>
                  </div>

                  <h3 class="h3 card-title">
                    <a href="#"><?= $row['CYCLE_NAME']; ?></a>
                  </h3>

                  <p class="card-text">
                    Beautiful Huge 1 Family House In Heart Of Westbury. Newly Renovated With New Wood
                  </p>

                  <ul class="card-list">

                    <li class="card-item">
                      <ion-icon name="bicycle-outline"></ion-icon>
                      <strong>FRAME</strong>
                      <span><?= $row['FRAME']; ?></span>
                    </li>
                    <li class="card-item">
                      <ion-icon name="bicycle-outline"></ion-icon>
                      <strong>FORK</strong>
                      <span><?= $row['FORK']; ?></span>
                    </li>
                    <li class="card-item">
                      <ion-icon name="bicycle-outline"></ion-icon>
                      <strong>GEAR</strong>
                      <span><?= $row['GEAR']; ?></span>
                    </li>
                    <li class="card-item">
                      <ion-icon name="bicycle-outline"></ion-icon>
                      <strong>TYRE</strong>
                      <span><?= $row['TYRE']; ?></span>
                    </li>
                    <li class="card-item">
                      <ion-icon name="bicycle-outline"></ion-icon>
                      <strong>BRAKES</strong>
                      <span><?= $row['BRAKES']; ?></span>
                    </li>
                    <li class="card-item">
                      <ion-icon name="bicycle-outline"></ion-icon>
                      <strong>RIMS</strong>
                      <span><?= $row['RIMS']; ?></span>
                    </li>
                    <li class="card-item">
                      <ion-icon name="bicycle-outline"></ion-icon>
                      <strong>BOTTOM_BRACKET</strong>
                      <span><?= $row['BOTTOM_BRACKET']; ?></span>
                    </li>
                    <li class="card-item">
                      <ion-icon name="bicycle-outline"></ion-icon>
                      <strong>RIDING_PURPOSE</strong>
                      <span><?= $row['RIDING_PURPOSE']; ?></span>
                    </li>
                    

                  </ul>

                </div>

               
              </div>
            </li>
            <?php } ?>

           

          </ul>

        </div>
      </section>





     




      <!-- 
        - #CTA
      -->

      <section class="cta">
        <div class="container">

          <div class="cta-card">
            <div class="card-content">
              <h2 class="h2 card-title">Looking for a Modern Cycle?</h2>
            </div>

            <button class="btn cta-btn" id="exploreBtn">
  <span>Explore Modern Cycle</span>
  <ion-icon name="arrow-forward-outline"></ion-icon>
</button>

<script>
  document.getElementById("exploreBtn").onclick = function() {
    window.location.href = "filter.php";
  };
</script>

          </div>

        </div>
      </section>

    </article>
  </main>





  <!-- 
    - #FOOTER
  -->

  <footer class="footer">

    <div class="footer-top">
      <div class="container">

        <div class="footer-brand">

          <a href="#" class="logo">
          Vel Cycle Mart
          </a>
          <ul class="contact-list">

            <li>
              <a href="#" class="contact-link">
                <ion-icon name="location-outline"></ion-icon>

                <address>9/85 Main Road, Vennandur, Namakkal-637505, Tamil Nadu, India</address>
              </a>
            </li>

            <li>
              <a href="tel:+0123456789" class="contact-link">
                <ion-icon name="call-outline"></ion-icon>

                <span>7010693709</span>
              </a>
            </li>

            <li>
              <a href="mailto:contact@homeverse.com" class="contact-link">
                <ion-icon name="mail-outline"></ion-icon>

                <span>velcycle@gmail.com</span>
              </a>
            </li>

          </ul>

       

        </div>

        <div class="footer-link-box">

          <ul class="footer-list">

            <li>
              <p class="footer-list-title">Company</p>
            </li>

            <li>
              <a href="#about" class="footer-link" id="about">About</a>
            </li>

            <li>
              <a href="filter.php" class="footer-link">All Products</a>
            </li>

            <!-- <li>
              <a href="" class="footer-link">Locations Map</a>
            </li> -->

            <!-- <li>
              <a href="#" class="footer-link">Contact us</a>
            </li> -->

          </ul>

          <ul class="footer-list">

            <li>
              <p class="footer-list-title">Service Timing</p>
            </li>

            <li>
              <a class="footer-link">Monday:      8AM-7.30PM</a>
            </li>

            <li>
              <a class="footer-link">Tuesday:        8AM-10PM </a>
            </li>

            <li>
              <a  class="footer-link">Wednesday:      9AM-10PM</a>
            </li>

            <li>
              <a class="footer-link">Thursday:      8AM-10PM</a>
            </li>

            <li>
              <a  class="footer-link">Friday:      8AM-7.30PM</a>
            </li>

            <li>
              <a class="footer-link">Sat & Sun:      10AM-5PM</a>
            </li>

          </ul>
         
          <ul class="footer-list">
          <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3909.501057663142!2d78.0904458!3d11.515870500000002!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMTHCsDMwJzU3LjEiTiA3OMKwMDUnMjUuNiJF!5e0!3m2!1sen!2sin!4v1714237786375!5m2!1sen!2sin" width="300" height="300" style="border:10px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </ul>

        </div>

      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">

        <p class="copyright">
          &copy; 2024 <a href="#">Vel Cycle Mart</a>. All Rights Reserved
        </p>

      </div>
    </div>

  </footer>





  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js"></script>

  <!-- 
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>

</html>