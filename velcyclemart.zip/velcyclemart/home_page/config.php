<?php

$con=mysqli_connect("localhost","root","","vels_cycle_mart");
if(!$con)
{
    echo "Connection Failed" . $con->mysqli_connect_error;
}
?>